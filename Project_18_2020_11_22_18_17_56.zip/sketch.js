var ball,ballImage,paddle,paddleImage;
function preload() {
  ballImage = loadImage("ball.png");
  paddleImage = loadImage("paddle.png");
}
function setup() {
  createCanvas(400, 400);
   /* create the Ball Sprite and the Paddle Sprite */
  ball = createSprite(30,200);
  paddle = createSprite(380,200);
  /* assign the images to the sprites */
  ball.addImage("ball", ballImage);
  paddle.addImage("paddle", paddleImage);
  
  /* give the ball an initial velocity of 9 in the X direction */
  ball.velocityX = 9;

}

function draw() {
  background(205,153,0);
  /* create Edge Sprites here */
  edges = createEdgeSprites();
  
  /* Allow the ball sprite to bounceOff the left, top and bottom edges only, leaving the right edge of the canvas to be open. */
  ball.bounceOff(paddle,randomVelocity);
  ball.bounceOff(edges[1]);
  ball.bounceOff(edges[2]);
  ball.bounceOff(edges[4]);

  /* Allow the ball to bounceoff from the paddle */
  /* Also assign a collision callback function, so that the ball can have a random y velocity, making the game interesting */
 
  /* Prevent the paddle from going out of the edges */ 
  paddle.collide(edges[1]);
  paddle.collide(edges[2]);
  paddle.collide(edges[2]);
  paddle.collide(edges[4]);
  
  if(keyDown(UP_ARROW))
  {
     paddle.velocityY = -3;
  }
  
  if(keyDown(DOWN_ARROW))
  {
   paddle.velocityY = 3;
  }
  drawSprites();
  
}

function randomVelocity()
{
  /* this function gets called when the ball bounces off the paddle */
  ball.velocityY = random(2,7);
  /* assign the ball a random vertical velocity, so it bounces off in random direction */
}

